import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ConcentrationGame extends JFrame implements ActionListener{
   private final int WINDOW_WIDTH=600;
   private final int WINDOW_HEIGHT=600;
   private JButton [] bMem= new JButton [16];
   private GameModel dealGame; 
   int i = 0;
   private JLabel result;
   int [] flipped = new int[16];
   
   public ConcentrationGame(){
   setTitle("Three Doors");
   setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
   setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   setLayout(new BorderLayout());
   
   Panel Mbuttons=new Panel();
   Mbuttons.setLayout(new GridLayout(4,4));
   
   dealGame = new FAKEConcentrationGameModel(); 
   
   for (int i=0; i<16; i++){
      bMem[i]=new JButton();
      bMem[i].addActionListener(this);
      Mbuttons.add(bMem[i]);
   }
   
   add(Mbuttons, BorderLayout.CENTER);
   setVisible(true);
   
   }
   
   public void actionPerformed (ActionEvent ae){
      JButton source = (JButton)ae.getSource();
      int i=0;
      while(source!=bMem[i])
         i++;
      dealGame.takeTurn(i, i);
      bMem[i].setIcon(dealGame.get(i));
      
   }     
}