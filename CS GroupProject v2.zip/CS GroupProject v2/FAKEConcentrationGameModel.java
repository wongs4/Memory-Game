import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class FAKEConcentrationGameModel extends GameModel{
   private ImageIcon [] images = new ImageIcon[16];
   private int [] clicks = new int [50];
   private int [] selected = new int [16];
   final int SIZE = 4;
   int numClicks = 0;
   boolean winner = false;
   boolean gameOver = false;
   int click1 = 0;
   int click2 = 0;
   
   FAKEConcentrationGameModel(){
      for(int t=0;t<8;t++){
         images[t] = new ImageIcon("goat3.jpg");
      }
      for(int t=8;t<16;t++){
         images[t] = new ImageIcon("vacation.jpg");
      }

      if(numClicks %2 == 0){
         for (int i=0;i<images.length;i++){
            String imageName = images[i].getDescription();
            String imageName2 = images[i].getDescription();
            if(imageName == imageName2){
              click1 = imageName.indexOf(i);//int location of imageName
              click2 = imageName2.indexOf(i);
            }
         }
      }
      else{
         for(int i=0;i<images.length;i++){
            images[i] = new ImageIcon("cardb.jpg");
         }
      }
   }

      public void takeTurn(int t,int c){
         numClicks++;
         int i = 0;
            if(i<images.length){
                  winner = true;}
               else {
                  winner = false;}  
      }     
      
      boolean gameOverStatus(){
         if(winner || numClicks == images.length)//this line essentially says the game
         //is over if there is a winner or all of the cards are flipped over
            return(true);
         else
            return(false);
      }
      
      ImageIcon get(int i){
      return(images[i]);
      }
      
      int getRows(){
      return(4);
      }
      
      int getCols(){
      return(SIZE);
      } 
      
      void display(){};     
       
      String reportWinner(){
         if(winner){
            return("your a winner");}
         else{
            return("You're a whiner. You suck. Congrats!");}
      }  
       
}