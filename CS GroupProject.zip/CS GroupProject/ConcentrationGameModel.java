import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class ConcentrationGameModel extends GameModel{
   private ImageIcon [] images = new ImageIcon[16];
   final int SIZE = 4;
   int winningPick = 0;
   int numberTurnedOver = 0;
   boolean winner = false;
   boolean gameOver = false;
   
   ConcentrationGameModel(){
      images[0] = new ImageIcon("circle.jpg");
      images[1] = new ImageIcon("hexagon.jpg");
      images[2] = new ImageIcon("Octagon.jpg");
      images[3] = new ImageIcon("oval.jpg");
      images[4] = new ImageIcon("rectangle.jpg");
      images[5] = new ImageIcon("rhombus.jpg");
      images[6] = new ImageIcon("square.jpg");
      images[7] = new ImageIcon("triangle.jpg");
      
      for(int i=0;i<images.length;i++){
         String imageName = images[i].getDescription();
         if(images[i] == images[i])
            winningPick = i;
      }
   }
   int getRows(){
      return(4);
   }
   int getCols(){
      return(SIZE);
   }
      
   public void takeTurn(int choice){
      numberTurnedOver++;
      if(choice == winningPick)
         winner = true;
   }
   
   //public boolean gameOverStatus(){
   
   void display(){};
   
   String reportWinner(){
      if(winner)
         return("Congrats! You won!");
      else
         return("Sorry, you lost");
   }
   
   int getSize(){
      return(SIZE);
   }
   
   ImageIcon getImage(int i){
      if(i>=0 && i<SIZE)
         return(images[i]);
      else
         return(images[0]);
   }
}
   