import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class FAKEConcentrationGameModel extends GameModel{
   private ImageIcon [] images = new ImageIcon[16];
   private int [] clicks = new int [50];
   final int SIZE = 4;
   int numClicks = 0;
   boolean winner = false;
   boolean gameOver = false;
   int click1 = 0;
   int click2 = 0;
   
   FAKEConcentrationGameModel(){
      for(int t=0;t<8;t++){
         images[t] = new ImageIcon("goat3.jpg");
      }
      for(int t=8;t<16;t++){
         images[t] = new ImageIcon("vacation.jpg");
      }
      for (int i=0;i<images.length;i++){
         String imageName = images[i].getDescription();//triangle in 3rd place
         String imageName2 = images[i].getDescription();//triangle
         if(imageName == imageName2){
           click1 = i;
           click2 = i;}
         else{
            images[i] = new ImageIcon(i+"");}
      }
}

      public void takeTurn(int t,int c){
         numClicks++;
         if(numClicks %2 == 0){
            if(t == click1 && c == click2){
               winner = true;}
            else {
               winner = false;}
         }
      }        
      
      boolean gameOverStatus(){
         if(winner || numClicks == images.length)//this line essentially says the game
         //is over if there is a winner or all of the cards are flipped over
            return(true);
         else
            return(false);
      }
      
      ImageIcon get(int i){
      return(images[i]);
      }
      
      int getRows(){
      return(4);
      }
      
      int getCols(){
      return(SIZE);
      } 
      
      void display(){};     
       
      String reportWinner(){
         if(winner){//maybe fix if game ends after two clicks
            return("your a winner");}
         else{
            return("You're a whiner. You suck. Congrats!");}
      }  
   
}