import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JOptionPane;

public class ConcentrationGame extends JFrame implements ActionListener{
   private final int WINDOW_WIDTH=1000;
   private final int WINDOW_HEIGHT=800;
   private JButton [] bMem= new JButton [16];
   int [] flipped = new int [16];
   private int [] saved=new int[3];
   private GameModel dealGame; 
   int i = 0;
   private JLabel result;
   
   public ConcentrationGame(){
   setTitle("Three Doors");
   setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
   setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   setLayout(new BorderLayout());
   
   Panel Mbuttons=new Panel();
   Mbuttons.setLayout(new GridLayout(4,4));
   
   dealGame = new ConcentrationGameModel(); 
   
   for (int i=0; i<16; i++){
      bMem[i]=new JButton();
      bMem[i].addActionListener(this);
      Mbuttons.add(bMem[i]);
      flipped[i] = 0;
   }
   
   add(Mbuttons, BorderLayout.CENTER);
   
   setVisible(true);
   
   }
   
   public void actionPerformed (ActionEvent ae){
      JButton source = (JButton)ae.getSource();
      int i=0;
      while(source!=bMem[i])
         i++;
      dealGame.takeTurn(i, i);
      if(false){
         bMem[i] = new JButton(i+"");}
      if (flipped[i] == 0){
         bMem[i].setIcon(dealGame.get(i));
         flipped[i] = 1;
      } else {
         bMem[i].setIcon(null);
         flipped[i] = 0;
      }
      if(dealGame.gameOverStatus())
         result.setText(dealGame.reportWinner());
         
      // dialog box
      Object[] options = {"Yes, please",
                          "No, thanks"};
      int n = JOptionPane.showOptionDialog(null,
          "Would you like to play again? ",
          "Game over",
          JOptionPane.YES_NO_CANCEL_OPTION,
          JOptionPane.QUESTION_MESSAGE,
          null,
          options,
          options[1]);
      // YES OPTION CLICKED
       if(n == 0){
           System.out.println("YES");
       }

       // NO OPTION CLICKED
       if(n == 1){
           System.out.println("NO");
       }

   }     
}