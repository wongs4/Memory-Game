class ConcentrationGameDriver{
   public static void main(String argv[]){
      ConcentrationGame cg = new ConcentrationGame();
   }
}