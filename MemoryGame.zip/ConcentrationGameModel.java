import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class ConcentrationGameModel extends GameModel{
   private ImageIcon [] images = new ImageIcon[16];
   private int [] clicks = new int [50];
   private int [] selected = new int [16];
   final int SIZE = 4;
   int numClicks = 0;
   boolean winner = false;
   boolean gameOver = false;
   int click1 = 0;
   int click2 = 0;
   
   ConcentrationGameModel(){
         images[0] = new ImageIcon("pup1.png");
         images[1] = new ImageIcon("pup3.png");
         images[2] = new ImageIcon("pup5.png");
         images[3] = new ImageIcon("pup7.png");
         images[4] = new ImageIcon("pup2.png");
         images[5] = new ImageIcon("pup4.png");
         images[6] = new ImageIcon("pup6.png");
         images[7] = new ImageIcon("pup8.png");
         images[8] = new ImageIcon("pup7.png");
         images[9] = new ImageIcon("pup5.png");
         images[10] = new ImageIcon("pup4.png");
         images[11] = new ImageIcon("pup3.png");
         images[12] = new ImageIcon("pup1.png");
         images[13] = new ImageIcon("pup2.png");
         images[14] = new ImageIcon("pup6.png");
         images[15] = new ImageIcon("pup8.png");

      if(numClicks %2 == 0){
         for (int i=0;i<images.length;i++){
            String imageName = images[i].getDescription();
            String imageName2 = images[i].getDescription();
            if(imageName == imageName2){
              click1 = imageName.indexOf(i);//int location of imageName
              click2 = imageName2.indexOf(i);
            }
         }
      }
      else{
         for(int i=0;i<images.length;i++){
            images[i] = new ImageIcon("cardb.jpg");
         }
      }
   }

      public void takeTurn(int t,int c){
         numClicks++;
         int i = 0;
            if(i<images.length){
                  winner = true;}
               else {
                  winner = false;}  
      }     
      
      boolean gameOverStatus(){
         if(winner || numClicks == images.length)//this line essentially says the game
         //is over if there is a winner or all of the cards are flipped over
            return(true);
         else
            return(false);
      }
      
      ImageIcon get(int i){
      return(images[i]);
      }
      
      int getRows(){
      return(4);
      }
      
      int getCols(){
      return(SIZE);
      } 
      
      void display(){};     
       
      String reportWinner(){
         if(winner){
            return("your a winner");}
         else{
            return("You're a whiner. You suck. Congrats!");}
      }  
       
}