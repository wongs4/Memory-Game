class ThreeDoorsDriver{

public static void main (String argv[]){
ThreeDoors th = new ThreeDoors();
}
}